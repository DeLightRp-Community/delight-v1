function setUpCameraApp(url){
    $('.phone-tab-button').click();
}


/* 
    <div class="phone-new-box-body">
        <div class="phone-new-box-main">
            <input class="phone-new-input-class" type="text" placeholder="Phone Number">
            <p> </p>
            <div class="phone-new-box-btn box-new-red" id="box-new-cancel">Cancel</div>
            <div class="phone-new-box-btn box-new-green">Submit</div>
        </div>
    </div>

    data-toggle="tooltip" title="Create Ad"

    $(document).on('click', '#a', function(e){
        e.preventDefault();
        ClearInputNew()
        $('#a').fadeOut(350);
    });


    var IDPlayer = $("#channel").val();

    PlayerChanseOf = $(this).data('chanse')
 */